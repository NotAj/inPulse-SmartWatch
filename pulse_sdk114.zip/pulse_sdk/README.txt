Getting Started:

http://www.getinpulse.com/guide/
