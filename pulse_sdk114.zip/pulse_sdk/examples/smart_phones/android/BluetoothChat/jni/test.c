#include <stdio.h>
 
int main()
{
	printf("Hello Google Android world!\nwww.pocketmagic.net\n");
	return 1;
	exit(0);
}
 