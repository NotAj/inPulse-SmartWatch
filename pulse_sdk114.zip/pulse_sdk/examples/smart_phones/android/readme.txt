A project called OpenWatch has inPulse support and if you load the notifications
app example, you can use OpenWatch to send messages to your wrist from your
Android smartphone.

http://beta.smartmadsoft.com/

The android app project included here show you how to connect and send test
messages to inPulse.
