Get inPulse working with your jailbroken iPhone!
Contact devsupport@getinpulse.com if you have some success!

This example worked once upon a time.
It is now quite out of date.

It is useful as a starting point.

See doc/pulse_protocol.odt for updated pulse protocol information.
