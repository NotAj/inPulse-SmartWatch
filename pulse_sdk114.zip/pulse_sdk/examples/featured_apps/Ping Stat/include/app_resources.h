#ifndef APP_RESOURCES_H
#define APP_RESOURCES_H

typedef enum PulseResource {
    IMAGE_NULL,
    IMAGE_RADAR,
    FONT_NULL,
    FONT_CLOCKOPIA_30,
    FONT_EASTA_10,
    NUM_PULSE_RESOURCES
};

#endif

