This script is WINDOWS ONLY.

In order to run the Python script, you will have to install the "Send Keys" library. You will need the Python specific version of the latest build. At the time of the release the version of Send Keys used for testing and developing was 0.3. You can see the latest builds here: http://www.rutherfurd.net/python/sendkeys/#dowloads

Before running the Python Script, make sure you run the L2CAPServer.jar first.

The python script accepts one command line parameter: the BT Address.
