#ifndef APP_RESOURCES_H
#define APP_RESOURCES_H

/* This file auto-generated on Sun Feb 13 18:10:38 2011 */

typedef enum PulseResource {
    IMAGE_NULL,
    IMAGE_NEXT_DOWN,
    IMAGE_NEXT_UP,
    IMAGE_PREV_DOWN,
    IMAGE_PREV_UP,
    IMAGE_TITLE,
    FONT_NULL,
    NUM_PULSE_RESOURCES
};

#endif

