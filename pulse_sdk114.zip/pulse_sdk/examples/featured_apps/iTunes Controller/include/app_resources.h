#ifndef APP_RESOURCES_H
#define APP_RESOURCES_H

/* This file auto-generated on Mon Feb 14 16:39:05 2011 */

enum PulseResource {
    IMAGE_NULL,
    IMAGE_NEXT,
    IMAGE_PAUSE,
    IMAGE_PLAY,
    IMAGE_TITLE,
    FONT_NULL,
    FONT_CANDC_12,
    NUM_PULSE_RESOURCES
};

#endif

