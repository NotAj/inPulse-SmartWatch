This script is WINDOWS ONLY.

In order to run the Python script, you will have to install the "pywin32" set of extensions. You will need the Python specific version of the latest build. At the time of the release the Build used for testing and developing was Build 214. You can see the latest builds here: http://sourceforge.net/projects/pywin32/files/pywin32/

Before running the Python Script, make sure you run the L2CAPServer.jar first.

The python script accepts one command line parameter: the BT Address.
