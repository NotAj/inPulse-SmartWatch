#ifndef APP_RESOURCES_H
#define APP_RESOURCES_H

typedef enum PulseResource {
    IMAGE_NULL,
    FONT_NULL,
    FONT_CLOCKOPIA_32,
    NUM_PULSE_RESOURCES
};

#endif

