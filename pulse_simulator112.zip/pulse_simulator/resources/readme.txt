Place your bmp, png, and ttf font files in this directory to be crunched into
a bin file to be sent from the watch.  Font rendering options need to be 
added to fonts.txt.

From the simulator root run:
python tools/resource_packer/resource_packer.py

You can follow this guide for creating your own resource packs:
http://www.getinpulse.com/guide/watchface/
